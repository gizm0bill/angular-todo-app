import { TestBed, inject } from '@angular/core/testing';

import { TodoService } from './todo.service';
import { Todo } from './todo';

describe('TodoDataService', () =>
{
  beforeEach( () => TestBed.configureTestingModule
  ({
    providers: [ TodoService ]
  }) );

  it( 'should be created', inject( [TodoService], ( service: TodoService ) => expect(service).toBeTruthy() ) );

  describe('#save(todo)', () =>
  {
    it('should automatically assign an incrementing id',
      ( done: DoneFn ) => inject( [ TodoService ], ( service: TodoService ) =>
      {
        const todo1 = new Todo({ name: 'Make dog bark', complete: true });
        service.createTodo( todo1 );
        service.todos$.subscribe( todos =>
        {
          expect( todos.find( todo => !!todo.id ) ).not.toBeNull();
          done();
        });
      })()
    );
  });
});
